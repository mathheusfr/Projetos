<section class="erro-404">
	<div class="center">

	<div class="wraper-404">
		<h2><i style="padding:0 10px;" class="fa fa-times"></i>A página Não Existe!</h2>
		<p>Deseja voltar para a <a href="<?php echo INCLUDE_PATH; ?>">página inicial</a>?</p>
	</div><!--wraper404-->
	</div><!--center-->
</section>