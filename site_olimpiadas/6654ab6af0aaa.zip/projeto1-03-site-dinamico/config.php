<?php 
	define('INCLUDE_PATH','http://localhost/projeto1-03-site-dinamico/');

?>